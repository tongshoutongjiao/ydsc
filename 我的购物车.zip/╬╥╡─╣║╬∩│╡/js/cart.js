/**
 * Created by wy on 2016/11/30.
 */
var cartJs = (function () {
    var $mark = $('.mark'),
        $markStore = $('.markStore'),
        $allSelect = $('.allSelect');
    $icon = $allSelect.children('.icon'),
        $add = $('.add'),
        $plus = $('.plus'),
        $editor = $('.editor'),
        $show = $('.show'),
        $standard = $('.standard'),
        $main = $('.main');
    $bounced = $('.bounced'),
        $part = $('.part');

    function brand(className) {
        className.tap(function () {
            var $null = $(this).find('.null'),
                flag = $(this).find('.null').css('display');
            flag === 'none' ? $null.show() : $null.hide()
        });
    };
    function brandStore(className) {
        var flag = 'none';
        className.tap(function () {
            var sib = $(this).parent().parent().find('.listContent').find('.mark');
            flag = $(this).children('.null').css('display');
            if (flag == 'block') {
                for (var i = 0; i < sib.length; i++) {
                    (function (i) {
                        var $null = $(sib[i]).children('.null');
                        $null.show();
                    })(i)
                }
                return flag = 'none';
            } else {
                for (i = 0; i < sib.length; i++) {
                    (function (i) {
                        var $null = $(sib[i]).children('.null');
                        $null.hide();
                    })(i)
                }
            }


        })
    };
    function selectAll() {
        var flag = 'none';
        brand($icon);
        $icon.tap(function () {
            console.log(flag);
            flag = $mark.children('.null').css('display');
            if (flag == 'block') {
                for (var i = 0; i < $mark.length; i++) {
                    (function (i) {
                        var $null = $($mark[i]).children('.null');
                        $null.hide();
                    })(i);
                }
                return flag = 'none';
            } else {
                for (i = 0; i < $mark.length; i++) {
                    (function (i) {
                        var $null = $($mark[i]).children('.null');
                        $null.show();
                    })(i);
                }
            }


        })


    }

    function add(num) {
        var count = Number(num.prev().html());
        count++;
        num.prev('.num').html(count);
    }

    function plus(num) {
        var count = Number(num.next().html());
        count--;
        num.next('.num').html(count);
    }

    function addBrand() {
        $add.tap(function () {
            add($(this));
        });
    }

    function plusBrand() {
        $plus.tap(function () {
            plus($(this));
        });
    }

    function complete() {
        var flag = true;
        $editor.tap(function () {
            $show.toggle().siblings('.hide').toggle();
            if (flag == true) {
                $(this).html('完成');
                return flag = false;
            } else {
                $(this).html('编辑');
                return flag = true;
            }
        })
    }

    function showSize(tar) {
        var flag = true;
        tar.tap(function (event) {
            event.stopPropagation();
            if (flag) {
                $bounced.css('display', 'block');
                $main.css('opacity', '0.5');
                setTimeout(function () {
                    $bounced.css('display', 'block')
                        .css('transition', 'all 1s')
                        .css('transform', 'translateY(-5.98rem)')
                }, 500);
                return flag = false;
            } else {
                $bounced.css('display', 'none');
                $main.css('opacity', '1');
                setTimeout(function () {
                    $bounced.css('display', 'none')
                        .css('transition', 'all 1s')
                        .css('transform', 'translateY(5.98rem)')
                }, 500);
                return flag = true;
            }
        });

    }

    function clearEvent() {
        $('section').tap(function () {
            $bounced.hide();
            $main.css('opacity', '1');
        })}

    function selectStyle() {
        $Ul = $part.children('ul'),
            $Li = $Ul.children('li');
        $Li.tap(function () {
            if (!$(this).hasClass('disabled')) {
                $(this).addClass('select').siblings().removeClass('select');
            }
        })
    }


    return {
        init: function () {
            brand($mark);
            brandStore($markStore);
            selectAll();
            addBrand();
            plusBrand();
            complete();
            showSize($standard);
            selectStyle();
            clearEvent();
        }
    }
})();
cartJs.init();




