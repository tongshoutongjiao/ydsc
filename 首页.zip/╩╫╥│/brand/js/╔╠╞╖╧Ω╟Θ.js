/**
 * Created by ww on 2016/12/2.
 */
//轮播
var mySwiper = new Swiper('.swiper-container', {

    loop: true,

    // 如果需要分页器
    pagination: '.swiper-pagination',

    // 如果需要前进后退按钮
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',

    // 如果需要滚动条
    scrollbar: '.swiper-scrollbar',
});


window.onload = function () {

    //点击三个圆点出现小弹框.................................................
    var flag = true;
    $('.more').tap(function () {
        //console.log(111);
        if (flag == true) {
            $('.brandList').css('display', 'block');
            return flag = false;
        } else {
            // console.log(222)
            $('.brandList').css("display", "none");
            flag = true;
        }
    });

    //点击商品详情评价添加横线及切换...........................................
    var lis = $('.goods li');
    for (var i = 0; i < lis.length; i++) {
        //console.log(lis[i])
        lis[i].index = i;
        $(lis[i]).tap(function () {
            $(this).addClass('selected').siblings().removeClass('selected');
            $('section').css('display', 'none');
            $('section').get(this.index).style.display = 'block'
        })

    }

    //点击购物车出现选择页面小动画,点击提交按钮关闭.........................................
    $('.myCart').tap(function () {
        // console.log(111);
        setTimeout(function () {
            // console.log($('.selectcolsize'));
            $('.selectcolsize').css('display', 'block')
                .css('transition', 'all 2s')
                .css('transform', 'translateY(-5rem)')
        }, 500);
    });
    //
    $('section').tap(function () {
        setTimeout(function () {
            $('.selectcolsize').css('display', 'none')
                .css('transition', 'all 1s')
                .css('transform', 'translateY(5rem)')
        }, 500);
    });

    $('submit').tap(function () {
        setTimeout(function () {
            $('.selectcolsize').css('display', 'none')
                .css('transition', 'all 1s')
                .css('transform', 'translateY(5rem)')
        }, 500);
    });

    //点击页面其他部分关闭弹出层

};
//点击详情页对应下面的图片
var pics = document.querySelectorAll('.two ul li');
for (var i = 0; i < pics.length; i++) {
    pics[i].index = i;
    pics[i].onclick = function () {
        var changepic = document.querySelector('.changepic');
        console.log(this.index)

        changepic.src = "./img/picture" + this.index + ".PNG";

    }
}


//评价页对应页面。。。。。。。。。。。。。。。。。。。。。。
$('.discuss li').tap(function () {
    $(this).addClass('select').siblings().removeClass('select');
    //记录被点击的索引
    console.log($(this).index());
    var index=$(this).index();

    // 遍历中评差评等对应的页面
    for (var i = 0; i < $('.arr').length; i++) {
        console.log( $('.arr').eq(index));
        $('.arr').eq(index).css('display','block').siblings().css('display','none')

    }
});




















